-- MySQL dump 10.13  Distrib 8.1.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: railwaysystemwebsite
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `weekdayroutes`
--

DROP TABLE IF EXISTS `weekdayroutes`;
/*!50001 DROP VIEW IF EXISTS `weekdayroutes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `weekdayroutes` AS SELECT 
 1 AS `RunningTimeID`,
 1 AS `RouteID`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `DayOfWeek`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `routetraininfo`
--

DROP TABLE IF EXISTS `routetraininfo`;
/*!50001 DROP VIEW IF EXISTS `routetraininfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `routetraininfo` AS SELECT 
 1 AS `RouteID`,
 1 AS `OperatingTrainID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `routeinfo`
--

DROP TABLE IF EXISTS `routeinfo`;
/*!50001 DROP VIEW IF EXISTS `routeinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `routeinfo` AS SELECT 
 1 AS `RouteID`,
 1 AS `Duration`,
 1 AS `Distance`,
 1 AS `TrainID`,
 1 AS `StartStation`,
 1 AS `EndStation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `routestartbetweentimerange`
--

DROP TABLE IF EXISTS `routestartbetweentimerange`;
/*!50001 DROP VIEW IF EXISTS `routestartbetweentimerange`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `routestartbetweentimerange` AS SELECT 
 1 AS `RouteID`,
 1 AS `StartTime`,
 1 AS `StartStation`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `averagerailcarweight`
--

DROP TABLE IF EXISTS `averagerailcarweight`;
/*!50001 DROP VIEW IF EXISTS `averagerailcarweight`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `averagerailcarweight` AS SELECT 
 1 AS `AverageWeight`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `traindetails`
--

DROP TABLE IF EXISTS `traindetails`;
/*!50001 DROP VIEW IF EXISTS `traindetails`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `traindetails` AS SELECT 
 1 AS `TrainID`,
 1 AS `MaximumWeight`,
 1 AS `TotalPassengerCount`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `railcarinfo`
--

DROP TABLE IF EXISTS `railcarinfo`;
/*!50001 DROP VIEW IF EXISTS `railcarinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `railcarinfo` AS SELECT 
 1 AS `ModelNumber`,
 1 AS `ModelName`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `routeschedule`
--

DROP TABLE IF EXISTS `routeschedule`;
/*!50001 DROP VIEW IF EXISTS `routeschedule`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `routeschedule` AS SELECT 
 1 AS `DayCategory`,
 1 AS `RouteID`,
 1 AS `StartStation`,
 1 AS `EndStation`,
 1 AS `StartTime`,
 1 AS `EndTime`,
 1 AS `DayOfWeek`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `ticketprices`
--

DROP TABLE IF EXISTS `ticketprices`;
/*!50001 DROP VIEW IF EXISTS `ticketprices`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ticketprices` AS SELECT 
 1 AS `AgeType`,
 1 AS `Cost`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `longestroutes`
--

DROP TABLE IF EXISTS `longestroutes`;
/*!50001 DROP VIEW IF EXISTS `longestroutes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `longestroutes` AS SELECT 
 1 AS `RouteID`,
 1 AS `Distance`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `weekdayroutes`
--

/*!50001 DROP VIEW IF EXISTS `weekdayroutes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `weekdayroutes` AS select `runningtimes`.`RunningTimeID` AS `RunningTimeID`,`runningtimes`.`RouteID` AS `RouteID`,`runningtimes`.`StartTime` AS `StartTime`,`runningtimes`.`EndTime` AS `EndTime`,`runningtimes`.`DayOfWeek` AS `DayOfWeek` from `runningtimes` where ((`runningtimes`.`DayOfWeek` <> 'Sunday') or (`runningtimes`.`DayOfWeek` = 'Saturday')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `routetraininfo`
--

/*!50001 DROP VIEW IF EXISTS `routetraininfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `routetraininfo` AS select `r`.`RouteID` AS `RouteID`,(select `t`.`TrainID` from (`trains` `t` join `routes` `rt` on((`rt`.`OperatingTrains` = `t`.`TrainID`))) where (`rt`.`RouteID` = `r`.`RouteID`)) AS `OperatingTrainID` from `routes` `r` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `routeinfo`
--

/*!50001 DROP VIEW IF EXISTS `routeinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `routeinfo` AS select `routes`.`RouteID` AS `RouteID`,`routes`.`Duration` AS `Duration`,`routes`.`Distance` AS `Distance`,`trains`.`TrainID` AS `TrainID`,`s1`.`Location` AS `StartStation`,`s2`.`Location` AS `EndStation` from (((`routes` join `trains` on((`routes`.`OperatingTrains` = `trains`.`TrainID`))) join `stations` `s1` on((`routes`.`StartStation` = `s1`.`StationID`))) join `stations` `s2` on((`routes`.`EndStation` = `s2`.`StationID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `routestartbetweentimerange`
--

/*!50001 DROP VIEW IF EXISTS `routestartbetweentimerange`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `routestartbetweentimerange` AS select `routes`.`RouteID` AS `RouteID`,`runningtimes`.`StartTime` AS `StartTime`,`routes`.`StartStation` AS `StartStation` from (`routes` join `runningtimes` on((`routes`.`RouteID` = `runningtimes`.`RouteID`))) where (`runningtimes`.`StartTime` between '09:00:00' and '13:00:00') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `averagerailcarweight`
--

/*!50001 DROP VIEW IF EXISTS `averagerailcarweight`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `averagerailcarweight` AS select avg(`railcars`.`Weight`) AS `AverageWeight` from `railcars` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `traindetails`
--

/*!50001 DROP VIEW IF EXISTS `traindetails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `traindetails` AS select `t`.`TrainID` AS `TrainID`,max(`r`.`Weight`) AS `MaximumWeight`,sum(`r`.`PassengerCapacity`) AS `TotalPassengerCount` from ((`trains` `t` join `railcars` `r` on((`t`.`BodyRailCarType` = `r`.`ModelNumber`))) join `routes` `rt` on((`t`.`TrainID` = `rt`.`OperatingTrains`))) where (`r`.`Category` = 'Passenger') group by `t`.`TrainID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `railcarinfo`
--

/*!50001 DROP VIEW IF EXISTS `railcarinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `railcarinfo` AS select `railcars`.`ModelNumber` AS `ModelNumber`,`railcars`.`ModelName` AS `ModelName` from (`railcars` left join `trains` on((`railcars`.`ModelNumber` = `trains`.`EngineRailCarType`))) union select `railcars`.`ModelNumber` AS `ModelNumber`,`railcars`.`ModelName` AS `ModelName` from (`trains` left join `railcars` on((`railcars`.`ModelNumber` = `trains`.`EngineRailCarType`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `routeschedule`
--

/*!50001 DROP VIEW IF EXISTS `routeschedule`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `routeschedule` AS select `combineddata`.`DayCategory` AS `DayCategory`,`combineddata`.`RouteID` AS `RouteID`,`combineddata`.`StartStation` AS `StartStation`,`combineddata`.`EndStation` AS `EndStation`,`combineddata`.`StartTime` AS `StartTime`,`combineddata`.`EndTime` AS `EndTime`,`combineddata`.`DayOfWeek` AS `DayOfWeek` from (select 'Weekday' AS `DayCategory`,`r`.`RouteID` AS `RouteID`,`r`.`StartStation` AS `StartStation`,`r`.`EndStation` AS `EndStation`,`rt`.`StartTime` AS `StartTime`,`rt`.`EndTime` AS `EndTime`,`rt`.`DayOfWeek` AS `DayOfWeek` from (`routes` `r` join `runningtimes` `rt` on((`r`.`RouteID` = `rt`.`RouteID`))) where (`rt`.`DayOfWeek` in ('Monday','Tuesday','Wednesday','Thursday','Friday')) union select 'Weekend' AS `DayCategory`,`r`.`RouteID` AS `RouteID`,`r`.`StartStation` AS `StartStation`,`r`.`EndStation` AS `EndStation`,`rt`.`StartTime` AS `StartTime`,`rt`.`EndTime` AS `EndTime`,`rt`.`DayOfWeek` AS `DayOfWeek` from (`routes` `r` join `runningtimes` `rt` on((`r`.`RouteID` = `rt`.`RouteID`))) where (`rt`.`DayOfWeek` in ('Saturday','Sunday'))) `combineddata` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticketprices`
--

/*!50001 DROP VIEW IF EXISTS `ticketprices`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticketprices` AS select `ticket`.`AgeType` AS `AgeType`,`ticket`.`Cost` AS `Cost` from `ticket` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `longestroutes`
--

/*!50001 DROP VIEW IF EXISTS `longestroutes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `longestroutes` AS select `routes`.`RouteID` AS `RouteID`,`routes`.`Distance` AS `Distance` from `routes` order by `routes`.`Distance` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-23 11:48:44
