-- MySQL dump 10.13  Distrib 8.1.0, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: railwaysystemwebsite
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `educationalinfotrain`
--

DROP TABLE IF EXISTS `educationalinfotrain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `educationalinfotrain` (
  `Header` varchar(255) NOT NULL,
  `information` varchar(255) DEFAULT NULL,
  `images` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Header`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `educationalinfotrain`
--

LOCK TABLES `educationalinfotrain` WRITE;
/*!40000 ALTER TABLE `educationalinfotrain` DISABLE KEYS */;
INSERT INTO `educationalinfotrain` VALUES ('Bullet','A bullet train is a high-speed passenger rail transport characterized by its high speed and rapid acceleration. It is known for its efficiency and punctuality.','https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Series-N700S-J2.jpg/1200px-Series-N700S-J2.jpg'),('Double-Decker','A double-decker train has two levels or decks for passengers. It provides increased seating capacity without increasing the trains length.','https://www.railway-technology.com/wp-content/uploads/sites/13/2023/07/230704_IR-Dosto-2-1.jpg'),('Electric Engine','An electric engine is a type of locomotive that uses electricity to power its engine. It is known for its efficiency and environmentally friendly operation.','https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Locomotive_ChS4-109_2012_G1.jpg/1200px-Locomotive_ChS4-109_2012_G1.jpg'),('Express','An express train is a type of train service that runs faster than the average train, making limited stops along its route. It is designed for long-distance travel and offers a quicker journey compared to regular trains.','https://upload.wikimedia.org/wikipedia/commons/4/48/Acela_old_saybrook_ct_summer2011.jpg'),('Single-Decker','A single-decker train has a single level for passengers. It is commonly used for shorter routes or where lower capacity is sufficient.','https://www.railwaypro.com/wp/wp-content/uploads/2022/11/flirt_vr-group-1024x683.jpg'),('Steam Engine','A steam engine is a locomotive that operates by using steam to generate power. It played a significant role in the history of trains, particularly during the industrial revolution.','https://i.ytimg.com/vi/P3F20t6PoYQ/maxresdefault.jpg');
/*!40000 ALTER TABLE `educationalinfotrain` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-23 11:48:44
